#include "stm32f10x.h"
#include "Hall_module.h"
#include "LED.h"


int main(void)
{
    LED_Init();//LED初始化(PB4)
		Hall_module_Init();//霍尔模块初始化(PA1)
    
    while(1)
    {
			if(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1) == Bit_RESET)//判断霍尔模块是否检测到磁铁
        {
            
            GPIO_WriteBit(GPIOB, GPIO_Pin_4, Bit_SET);//LED 亮
        }
        else
        {
            GPIO_WriteBit(GPIOB, GPIO_Pin_4, Bit_RESET);//LED 灭
        }
    }
}
