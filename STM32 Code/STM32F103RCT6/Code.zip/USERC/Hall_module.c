#include "Hall_module.h"

void Hall_module_Init(void)//霍尔模块初始化(PA1)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    
    /* Enable GPIOA */
    /* 使能GPIOA时钟 */
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE); 
    
    /* Configure PA1 in Floating input mode */
    /* 配置PA1 浮空输入模式 */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;   
    GPIO_Init(GPIOA, &GPIO_InitStructure);  
}
