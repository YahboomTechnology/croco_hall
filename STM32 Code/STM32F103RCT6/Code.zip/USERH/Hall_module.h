#ifndef __HALL_MOUDLE_H__
#define __HALL_MOUDLE_H__

#include "stm32f10x.h"

void Hall_module_Init(void);//霍尔模块初始化(PA1)

#endif
